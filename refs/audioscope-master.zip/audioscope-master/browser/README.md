Audioscope JS
=============

A collection of audio visualizers true to the sound, for the browser.

Build
=====

TODO
